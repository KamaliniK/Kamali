#GETTING INPUT OF DATE,MONTH ,YEAR AND PRINTING AS DATE OF  BIRTH
date=input("Enter your date of birth:")
month=input("Enter your month of birth:")
year=input("Enter your year of birth:")
#using sep and printing date of birth in DD/MM/YYYY format
print("your date of birth :",date,month,year,sep="-")

#-------------------------------------------------------------------
#OUTPUT
'''
Enter your date of birth:16
Enter your month of birth:07
Enter your year of birth:2004
your date of birth :-16-07-2004
'''
#-------------------------------------------------------------------
