a=float(input("Enter the value of a:")) #gets the value as string and converts into int by type casting
b=float(input("Enter the value of b:"))  #gets the value as string and converts into int by type casting
#The char "f" also known as f-string which contains expressions inside braces,The expressions are replaced with their values 
print(f"The value of {a} + {b} is {a+b}") # a and b are added
print(f"The value of {a} - {b} is {a-b}") # a and b are subtracted
print(f"The value of {a} * {b} is {a*b}") # a and b are multiplied
print(f"The value of {a} / {b} is {a/b}") # a and b are divided
print(f"The value of {a} % {b} is {a%b}") # a and b are divided and the remainder will be the output
print(f"The value of {a} ** {b} is {a**b}") # a and b are exponential for ex(2**3=8)

'''
Enter the value of a:1.01
Enter the value of b:1.01
The value of 1.01 + 1.01 is 2.02
The value of 1.01 - 1.01 is 0.0
The value of 1.01 * 1.01 is 1.0201
The value of 1.01 / 1.01 is 1.0
The value of 1.01 % 1.01 is 0.0
The value of 1.01 ** 1.01 is 1.0101005033417416

'''
